# Lab 3 - External Hardware

## Build instructions 

To build a pdf of the instructions: 

```bash
cd instructions 
pandoc instructions.md -o instructions.pdf --pdf-engine=wkhtmltopdf
``` 

Needs wkhtmltopdf installed. 
